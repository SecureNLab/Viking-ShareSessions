<?php
$html.=<<<A
<img class=player src="include/ray.png" />
<p class=nabname>
Ray Allen (Ray Allen), was born on July 20, 1975 in California, the beauty of xi, American professional basketball player, the secretary shooting guard, has excellent 3-point shooting ability.
</p>
A;
?>