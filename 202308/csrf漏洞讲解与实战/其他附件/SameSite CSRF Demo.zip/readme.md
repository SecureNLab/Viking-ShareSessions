一个基于Samesite属性由Lax自动变化为None的CSRF攻击Demo。

默认在本地部署，域名为127.0.0.2即可。